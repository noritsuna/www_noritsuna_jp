package jp.android_group.artoolkit.hardware;

import android.hardware.Camera.Parameters;
import android.hardware.Camera.PreviewCallback;

/**
 * It is an interface for cameras. 
 * 
 * @author noritsuna
 *
 */
public interface CameraIF {
	
	public void release();
    public void setPreviewCallback(PreviewCallback cb);
	
    public void setParameters(Parameters params);
    public Parameters getParameters();
    
    public void startPreview();
    public void stopPreview();
    
}
