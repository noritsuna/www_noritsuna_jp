/* 
 * PROJECT: NyARToolkit on Android
 * --------------------------------------------------------------------------------
 * This work is based on the NyARToolKit developed by
 *   R.Iizuka
 * http://www.hitl.washington.edu/artoolkit/
 *
 * The NyARToolkit on Android is an Application of NyARToolkit 
 * to Google Android Emulator Environment.
 * Copyright (C)2008 Shinobu Izumi
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this framework; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * For further information please contact.
 *	<stagesp1(at)gmail.com>
 * 
 */
package jp.android_group.artoolkit;

import java.io.InputStream;

import jp.android_group.artoolkit.hardware.AttachedCamera;
import jp.android_group.artoolkit.hardware.CameraIF;
import jp.android_group.artoolkit.hardware.SocketCamera;
import jp.android_group.artoolkit.hardware.StaticCamera;
import jp.android_group.artoolkit.object.Cube;
import jp.nyatla.nyartoolkit.NyARException;
import jp.nyatla.nyartoolkit.core.NyARCode;
import jp.nyatla.nyartoolkit.core.raster.NyARRaster_RGB;
import jp.nyatla.nyartoolkit.jogl.utils.GLNyARParam;
import jp.nyatla.nyartoolkit.jogl.utils.GLNyARSingleDetectMarker;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.hardware.Camera;
import android.hardware.Camera.PreviewCallback;
import android.os.Bundle;
import android.util.Log;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

/**
 * Main activity.
 * 
 * @author noritsuna
 *
 */
public class NyARToolkitAndroidActivity extends Activity {


	private final int WC = ViewGroup.LayoutParams.WRAP_CONTENT;
	private final int FP = ViewGroup.LayoutParams.FILL_PARENT;

	private GLSurfaceView mGLSurface;
	private ObjectRenderer mRenderer;

	private CameraIF mCamera;
	
	private LinearLayout linearLayout;
	private RelativeLayout relativeLayout;
	
	@Override
	protected void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		Log.d("NyARToolkitAndroidActivity", "onCreate");

		// Hide the window title.
		requestWindowFeature(Window.FEATURE_NO_TITLE);

		// Create window.
		linearLayout = new LinearLayout(this);
		linearLayout.setOrientation(LinearLayout.VERTICAL);
		setContentView(linearLayout);

		relativeLayout = new RelativeLayout(this);

		mGLSurface = new GLSurfaceView(this);
 		relativeLayout.addView(mGLSurface, 
 							   new RelativeLayout.LayoutParams(WC, WC));

		linearLayout.addView(relativeLayout);

		mRenderer = new ObjectRenderer(true, new Cube());
        mGLSurface.setRenderer(mRenderer);
        mGLSurface.requestFocus();
		
        
		// setup camera.
		if(getString(R.string.camera_name).equals("jp.android_group.artoolkit.hardware.SocketCamera")) {
			mCamera = new SocketCamera(getString(R.string.server_addr),
					Integer.valueOf(getString(R.string.server_port)));
		} else if(getString(R.string.camera_name).equals("jp.android_group.artoolkit.hardware.AttachedCamera")) {
			mCamera = new AttachedCamera();
		} else if(getString(R.string.camera_name).equals("jp.android_group.artoolkit.hardware.StaticCamera")) {
			mCamera = new StaticCamera(getAssets());
		} else {
			mCamera = new AttachedCamera();
		}
		mCamera.setPreviewCallback(previewCB);
		
		Log.d("trace", "finish onCreate");
	}

	@Override
	protected void onPause() {
		Log.d("NyARToolkitAndroidActivity", "call onPause");
		super.onPause();
		mCamera.stopPreview();
	}
	@Override
	protected void onStart() {
		Log.d("NyARToolkitAndroidActivity", "call onStart");
		super.onStart();
		// start camera.
		mCamera.startPreview();
	}
	@Override
	protected void onStop() {
		Log.d("NyARToolkitAndroidActivity", "call onStop");
		super.onStop();
		mCamera.stopPreview();
		mCamera.release();
	}



	
//----------------------- part of ARToolkit. -------------------------//
	
	private GLNyARSingleDetectMarker nya = null;
	private NyARRaster_RGB raster = new NyARRaster_RGB();
	private GLNyARParam ar_param = new GLNyARParam();
	private NyARCode ar_code = new NyARCode(16, 16);

	private void createNyARTool(int w, int h) {
		InputStream camePara = getResources().openRawResource(
				R.raw.camera_para);
		InputStream patt = getResources().openRawResource(
				R.raw.patt);

		// NyARToolkit setting.
		try {
			ar_param.loadFromARFile(camePara);
			ar_param.changeSize(w, h);
			ar_code.loadFromARFile(patt);
			nya = new GLNyARSingleDetectMarker(ar_param, ar_code, 80.0);
			nya.setContinueMode(true);
			Log.d("nyar", "resources have been loaded");
		} catch (Exception e) {
			Log.e("nyar", "resource loading failed", e);
		}

	}
	
	private PreviewCallback previewCB = new CameraPreviewCallbackForAR();
    private class CameraPreviewCallbackForAR implements PreviewCallback {
    	
		//Options opt = new Options();
		//Bitmap bitmap_orig = null;
    	
		@Override
		public void onPreviewFrame(byte[] data, Camera camera) {
			
			if(data == null) {
				Log.d("CameraPreviewCallbackForAR", "data= null");
				return;
			}
			
			Log.d("CameraPreviewCallbackForAR", "data.length= " + data.length);
			Bitmap bitmap = null;
			bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
			if (bitmap == null) {
				return;
			}
			bitmap = Bitmap.createBitmap(bitmap, 0, 0, 128, 256);
			
			Log.d("CameraPreviewCallbackForAR", "bitmap.getHeight()= " + bitmap.getHeight());
			Log.d("CameraPreviewCallbackForAR", "bitmap.getWidth()= " + bitmap.getWidth());
			if(nya == null) {
				Log.d("CameraPreviewCallbackForAR", "createNyARTool");
				createNyARTool(bitmap.getWidth(), bitmap.getHeight());
			}
			
			mRenderer.setBgBitmap(bitmap);
			// start coordinates calculation.
			int w = bitmap.getWidth();
			int h = bitmap.getHeight();
			int[] pixels = new int[w * h];
			byte[] buf = new byte[pixels.length * 3];
			float[] resultf = new float[16];
			
			boolean is_marker_exist = false;
			bitmap.getPixels(pixels, 0, w, 0, 0, w, h);
			Log.d("CameraPreviewCallbackForAR", "pixels:" + pixels.length);

			for (int i = 0; i < pixels.length; i++) {
				int argb = pixels[i];
				// byte a = (byte) (argb & 0xFF000000 >> 24);
				byte r = (byte) (argb & 0x00FF0000 >> 16);
				byte g = (byte) (argb & 0x0000FF00 >> 8);
				byte b = (byte) (argb & 0x000000FF);
				buf[i * 3] = r;
				buf[i * 3 + 1] = g;
				buf[i * 3 + 2] = b;
			}

			NyARRaster_RGB.wrap(raster, buf, w, h);
			// Marker detection 
			try {
				Log.d("CameraPreviewCallbackForAR", "Marker detection.");
				is_marker_exist = nya.detectMarkerLite(raster, 100);
			} catch (NyARException e) {
				Log.e("CameraPreviewCallbackForAR", "marker detection failed", e);
				return;
			}
			
			// An OpenGL object will be drawn if matched.
			if (is_marker_exist) {
				Log.d("CameraPreviewCallbackForAR", "exist marker.");
				// Projection transformation.
				float[] cameraRHf = ar_param.getCameraFrustumRHf();
				try {
					nya.getCameraViewRH(resultf);
				} catch (NyARException e) {
					Log.e("CameraPreviewCallbackForAR", "getCameraViewRH failed", e);
					return;
				}
				mRenderer.objectPointChanged(resultf, cameraRHf);
			} else {
				Log.d("CameraPreviewCallbackForAR", "not exist marker.");
				mRenderer.objectClear();
			}

		}
    
    }

}
