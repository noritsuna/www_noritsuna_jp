package jp.android_group.artoolkit.object;

import javax.microedition.khronos.opengles.GL10;

/**
 * It is an interface of 3D object which ARtoolkit draws. 
 * 
 * @author noritsuna
 *
 */
public interface ARObject {
	public void draw(GL10 gl);
}
