set JAVA_TOOLS=C:\data\MyDocuments\MyProgram\JAVA\ProgramTools

set MAVEN_HOME=C:\data\MyDocuments\MyProgram\JAVA\ProgramTools\apache-maven-2.0.9
set PROJECT_HOME=C:\data\MyDocuments\Business\personal\android\dev\eclipse-0.9\NyARToolkitAndroid\WebcamBroadcaster


set ANT_HOME=%JAVA_TOOLS%\apache-ant-1.6.3
set JAVA_HOME=%JAVA_TOOLS%\jdk1.5.0_07

set PATH=%PATH%;%ANT_HOME%\bin
set PATH=%PATH%;%JAVA_HOME%\bin
set PATH=%PATH%;%MAVEN_HOME%\bin

set PATH=%PROJECT_HOME%\lib;%PATH%

