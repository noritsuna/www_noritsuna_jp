次世代アマチュア衛星受信のスタンダード「SDR+GNU Radio」環境構築・使いこなし指南
https://www.noritsuna.jp/grc_study_doc.pdf

用の演習ファイルです。
