/*
 * Copyright (C) 2008 Japan Android Group.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package jp.android_group.artoolkit.object;

import android.content.res.AssetFileDescriptor;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.util.Log;

/**
 * 
 * 
 * @author noritsuna
 *
 */
public class VoicePlayer {

    MediaPlayer mVoiceSound;
    
    public void initVoice(AssetFileDescriptor afd) {
        try {
        	mVoiceSound = new MediaPlayer();

            mVoiceSound.setDataSource(afd.getFileDescriptor(),
                             afd.getStartOffset(),
                             afd.getLength());
            mVoiceSound.setLooping(true);

            if (mVoiceSound != null) {
            	mVoiceSound.setAudioStreamType(AudioManager.STREAM_SYSTEM);
            	mVoiceSound.prepare();
            }
        	mVoiceSound.seekTo(0);
        	mVoiceSound.start();
        	mVoiceSound.pause();
        } catch (Exception ex) {
            Log.w("VoicePlayer", "Couldn't create click sound", ex);
        }
    }
    
    public void startVoice() {
    	if(!mVoiceSound.isPlaying()) {
    		mVoiceSound.pause();
    	}
    }
    public void stopVoice() {
    	if(mVoiceSound.isPlaying()) {
    		mVoiceSound.pause();
    	}
    }

}
