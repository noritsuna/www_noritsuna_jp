package jp.android_group.artoolkit;

import java.io.InputStream;

import jp.android_group.artoolkit.model.VoicePlayer;
import jp.nyatla.nyartoolkit.NyARException;
import jp.nyatla.nyartoolkit.core.NyARCode;
import jp.nyatla.nyartoolkit.core.param.NyARParam;
import jp.nyatla.nyartoolkit.core.raster.rgb.NyARRgbRaster_RGB;
import jp.nyatla.nyartoolkit.core.transmat.NyARTransMatResult;
import jp.nyatla.nyartoolkit.detector.NyARSingleDetectMarker;
import jp.nyatla.nyartoolkit.jogl.utils.NyARGLUtil;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

public class ARToolkitDrawer {
	
	private NyARSingleDetectMarker nya = null;
	private NyARRgbRaster_RGB raster = null;
	private NyARGLUtil ar_util = null;
	private NyARParam ar_param = null;
	private NyARCode ar_code = new NyARCode(16, 16);
	private NyARTransMatResult ar_transmat_result = new NyARTransMatResult();

	
	protected ModelRenderer mRenderer = null;
	protected InputStream camePara = null;
	protected InputStream patt = null;
	
	protected VoicePlayer mVoiceSound = null;
	
	public ARToolkitDrawer(InputStream camePara, InputStream patt, ModelRenderer mRenderer) {
		this.camePara = camePara;
		this.patt = patt;
		this.mRenderer = mRenderer;
	}
	
	private void createNyARTool(int w, int h) {
		// NyARToolkit setting.
		try {
			if (ar_param == null) {
				ar_util = new NyARGLUtil();
				ar_param = new NyARParam();
				ar_param.loadARParam(camePara);
				ar_code.loadARPatt(patt);
				//TODO 本当は、ここはifの外でないと行けない。だけど、出すとOutOfMemory
				ar_param.changeScreenSize(w, h);
				nya = new NyARSingleDetectMarker(ar_param, ar_code, 80.0);
				nya.setContinueMode(false);
			}
			Log.d("nyar", "resources have been loaded");
		} catch (Exception e) {
			Log.e("nyar", "resource loading failed", e);
		}

	}

	public void setVoicePlayer(VoicePlayer mVoiceSound) {
		this.mVoiceSound = mVoiceSound;
	}

	public void draw(byte[] data) {
		
		if(data == null) {
			Log.d("AR draw", "data= null");
			return;
		}
		Log.d("AR draw", "data.length= " + data.length);
		
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = 4;
        Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length, options);
		if (bitmap == null) {
			Log.d("AR draw", "data is not BitMap.");
			return;
		}
		if(bitmap.getHeight() < 240) {
			bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
		}
		if(bitmap.getHeight() < 240) {
			Log.d("AR draw", "data is too small size.");
			return;
		}

					
		Log.d("AR draw", "bitmap.getHeight()= " + bitmap.getHeight());
		Log.d("AR draw", "bitmap.getWidth()= " + bitmap.getWidth());
		mRenderer.setBgBitmap(bitmap);
		// start coordinates calculation.
		int w = bitmap.getWidth();
		int h = bitmap.getHeight();
		int[] pixels = new int[w * h];
		byte[] buf = new byte[pixels.length * 3];
		float[] resultf = new float[16];
		
		boolean is_marker_exist = false;
		bitmap.getPixels(pixels, 0, w, 0, 0, w, h);
		Log.d("AR draw", "pixels:" + pixels.length);

		for (int i = 0; i < pixels.length; i++) {
			int argb = pixels[i];
			// byte a = (byte) (argb & 0xFF000000 >> 24);
			byte r = (byte) (argb & 0x00FF0000 >> 16);
			byte g = (byte) (argb & 0x0000FF00 >> 8);
			byte b = (byte) (argb & 0x000000FF);
			buf[i * 3] = r;
			buf[i * 3 + 1] = g;
			buf[i * 3 + 2] = b;
			argb = pixels[i];
		}
		
		createNyARTool(w, h);
		raster = NyARRgbRaster_RGB.wrap(buf, w, h);
		// Marker detection 
		try {
			Log.d("AR draw", "Marker detection.");
			is_marker_exist = nya.detectMarkerLite(raster, 100);
		} catch (NyARException e) {
			Log.e("AR draw", "marker detection failed", e);
			return;
		}
		
		// An OpenGL object will be drawn if matched.
		if (is_marker_exist) {
			Log.d("AR draw", "!!!!!!!!!!!exist marker.!!!!!!!!!!!");
			// Projection transformation.
			float[] cameraRHf = new float[16];
			ar_util.toCameraFrustumRHf(ar_param, cameraRHf);
			try {
				NyARTransMatResult transmat_result = ar_transmat_result;
				nya.getTransmationMatrix(transmat_result);
				ar_util.toCameraViewRHf(transmat_result, resultf);
			} catch (NyARException e) {
				Log.e("AR draw", "getCameraViewRH failed", e);
				return;
			}
			mRenderer.objectPointChanged(resultf, cameraRHf);
			if(mVoiceSound != null)
				mVoiceSound.startVoice();
		} else {
			Log.d("AR draw", "not exist marker.");
			if(mVoiceSound != null)
				mVoiceSound.stopVoice();
			mRenderer.objectClear();
		}

	}
	
	// decode Y, U, and V values on the YUV 420 buffer described as YCbCr_422_SP by Android 
	public static void decodeYUV(byte[] out, byte[] fg, int width, int height) throws NullPointerException, IllegalArgumentException { 
	        final int sz = width * height; 
	        if(out == null) throw new NullPointerException("buffer 'out' is null"); 
	        if(out.length < sz) throw new IllegalArgumentException("buffer 'out' size " + out.length + " < minimum " + sz); 
	        if(fg == null) throw new NullPointerException("buffer 'fg' is null"); 
	        if(fg.length < sz) throw new IllegalArgumentException("buffer 'fg' size " + fg.length + " < minimum " + sz * 3/ 2); 
	        int i, j; 
	        int Y, Cr = 0, Cb = 0; 
	        for(j = 0; j < height; j++) { 
	                int pixPtr = j * width; 
	                final int jDiv2 = j >> 1; 
	                for(i = 0; i < width; i++) { 
	                        Y = fg[pixPtr]; if(Y < 0) Y += 255; 
	                        if((i & 0x1) != 1) { 
	                                final int cOff = sz + jDiv2 * width + (i >> 1) * 2; 
	                                Cb = fg[cOff]; 
	                                if(Cb < 0) Cb += 127; else Cb -= 128; 
	                                Cr = fg[cOff + 1]; 
	                                if(Cr < 0) Cr += 127; else Cr -= 128; 
	                        } 
	                        int R = Y + Cr + (Cr >> 2) + (Cr >> 3) + (Cr >> 5); 
	                        if(R < 0) R = 0; else if(R > 255) R = 255; 
	                        int G = Y - (Cb >> 2) + (Cb >> 4) + (Cb >> 5) - (Cr >> 1) + (Cr >> 3) + (Cr >> 4) + (Cr >> 5); 
	                        if(G < 0) G = 0; else if(G > 255) G = 255; 
	                        int B = Y + Cb + (Cb >> 1) + (Cb >> 2) + (Cb >> 6); 
	                        if(B < 0) B = 0; else if(B > 255) B = 255; 
	                        out[pixPtr++] = (byte)(0xff000000 + (B << 16) + (G << 8) + R); 
	                } 
	        } 
	} 

	
}
