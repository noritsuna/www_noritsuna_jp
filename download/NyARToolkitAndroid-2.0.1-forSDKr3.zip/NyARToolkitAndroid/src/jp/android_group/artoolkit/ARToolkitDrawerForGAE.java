package jp.android_group.artoolkit;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.multipart.ByteArrayPartSource;
import org.apache.commons.httpclient.methods.multipart.FilePart;
import org.apache.commons.httpclient.methods.multipart.MultipartRequestEntity;
import org.apache.commons.httpclient.methods.multipart.Part;
import org.apache.commons.httpclient.methods.multipart.StringPart;
import org.apache.http.util.ByteArrayBuffer;

import jp.android_group.artoolkit.ARToolkitDrawer;
import jp.android_group.artoolkit.ModelRenderer;
import jp.nyatla.utils.ByteUtil;
import jp.nyatla.utils.IntArrayValue;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

public class ARToolkitDrawerForGAE extends ARToolkitDrawer {

	final static private String ARTOOLKIT_URI = "http://nyartoolkit-20.appspot.com/nyartoolkitforgae_server/arDetect";
	
	
	private byte[] cameParaByte = new byte[1600];
	private byte[] pattBytes = new byte[16000];

	private FilePart cameraParaPart = null;
	private FilePart pattPart = null;
	private Part[] parts = null;

	
	private float[] cameraRHf  = new float[16];
	private float[] resultf = new float[16];
	
	public ARToolkitDrawerForGAE(InputStream camePara, InputStream patt, ModelRenderer mRenderer) {
		super(camePara, patt, mRenderer);
		
    	try {
	    	camePara.read(cameParaByte);
			patt.read(pattBytes);
		} catch (IOException e1) {
			e1.printStackTrace();
			return;
		}
    	cameraParaPart = new FilePart("camePara", new ByteArrayPartSource("camePara", cameParaByte));
    	pattPart = new FilePart("patt", new ByteArrayPartSource("patt", pattBytes));
        parts = new Part[5];
        parts[0] = cameraParaPart;
        parts[1] = pattPart;

	}

	public void draw(byte[] data) {
		
		if(data == null) {
			Log.d("AR draw", "data= null");
			return;
		}
		Log.d("AR draw", "data.length= " + data.length);
		
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = 4;
        Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length, options);
		if (bitmap == null) {
			Log.d("AR draw", "data is not BitMap.");
			return;
		}
		if(bitmap.getHeight() < 240) {
			bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
		}
		if(bitmap.getHeight() < 240) {
			Log.d("AR draw", "data is too small size.");
			return;
		}

					
		Log.d("AR draw", "bitmap.getHeight()= " + bitmap.getHeight());
		Log.d("AR draw", "bitmap.getWidth()= " + bitmap.getWidth());
		mRenderer.setBgBitmap(bitmap);
		// start coordinates calculation.
		int w = bitmap.getWidth();
		int h = bitmap.getHeight();
		int[] pixels = new int[w * h];
		bitmap.getPixels(pixels, 0, w, 0, 0, w, h);

		boolean is_marker_exist = isExistMarker(ByteUtil.o2b(new IntArrayValue(pixels)), w, h);
		
		// An OpenGL object will be drawn if matched.
		if (is_marker_exist) {
			Log.d("AR draw", "!!!!!!!!!!!exist marker.!!!!!!!!!!!");
			mRenderer.objectPointChanged(resultf, cameraRHf);
			if(mVoiceSound != null)
				mVoiceSound.startVoice();
		} else {
			Log.d("AR draw", "not exist marker.");
			if(mVoiceSound != null)
				mVoiceSound.stopVoice();
			mRenderer.objectClear();
		}

	}
	
    int responseCode = 0;
    int count = 0;
	private boolean isExistMarker(byte[] cameraImage, int w, int h) {
		Log.d("AR isExistMarker", "in isExistMarker.");
		
		responseCode = 0;
		count = 0;
		
        PostMethod method = new PostMethod(ARTOOLKIT_URI);
        parts[2] = new FilePart("cameImage", new ByteArrayPartSource("cameImage", cameraImage));
        parts[3] = new StringPart("width", Integer.toString(w));
        parts[4] = new StringPart("height", Integer.toString(h));
        method.setRequestEntity(new MultipartRequestEntity(parts, method.getParams()));

        HttpClient client = null;
		try {
			client = new HttpClient();
			Log.d("AR isExistMarker", "Http connection!!!");
			responseCode = client.executeMethod(method);
			if(responseCode != 200) {
				Log.d("AR isExistMarker", "not 200 response.");
				return false;
			}
			String respStr = method.getResponseBodyAsString();
			if(respStr == null) {
				Log.d("AR isExistMarker", "respons is null");
			} else {
				Log.d("AR isExistMarker", "respons is " + respStr);
			}
			
			String[] resp = respStr.split(",");
			if( resp.length < 32 ) {
				Log.d("AR isExistMarker", "not 32 length response.");
				return false;
			}
			for(; count < 16; count++) {
				cameraRHf[count] = Float.valueOf(resp[count]);
			}
			for(; count < 32; count++) {
				resultf[count-16] = Float.valueOf(resp[count]);
			}
			return true;
		} catch (HttpException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			method.releaseConnection();
		}
		return false;
		
	}
	
}
