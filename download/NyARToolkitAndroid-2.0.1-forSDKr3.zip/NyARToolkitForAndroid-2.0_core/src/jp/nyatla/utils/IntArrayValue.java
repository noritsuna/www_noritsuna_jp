package jp.nyatla.utils;

import java.io.Serializable;

public class IntArrayValue implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	public int[] intArray;
	
	public IntArrayValue() {
		
	}

	public IntArrayValue(int[] intArray) {
		this.intArray = intArray;
	}
	
}
