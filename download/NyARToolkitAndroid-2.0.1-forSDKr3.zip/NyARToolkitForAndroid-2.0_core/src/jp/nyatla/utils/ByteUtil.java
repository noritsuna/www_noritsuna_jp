package jp.nyatla.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ByteUtil {
	
	public static byte[] o2b(Object o){
		try{
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(baos);
			oos.reset();
			oos.writeObject(o);
			oos.flush();
			byte[] data = baos.toByteArray();
			return data;
	    } catch(Exception ex) {
	        System.err.println(ex);
	    }
	    return null;
	}
	
	public static Object b2o(byte[] b){
		try{
			ByteArrayInputStream bais = new ByteArrayInputStream(b);
			ObjectInputStream ois = new ObjectInputStream(bais);
			Object o = ois.readObject();
			return o;
		} catch(Exception ex){
			System.err.println(ex);
		}
      return null;
   }

}
