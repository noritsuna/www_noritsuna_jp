package ow.android;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.Set;

import ow.MessageObject;
import ow.dht.DHT;
import ow.dht.DHTConfiguration;
import ow.dht.DHTFactory;
import ow.dht.ValueInfo;
import ow.id.ID;
import ow.messaging.util.MessagingUtility;
import ow.routing.RoutingException;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class OWActivity extends Activity {
	
	
	private final static short APPLICATION_ID = 0x01;
	private final static short APPLICATION_VERSION = 2;
	
	private final static int OW_PORT = DHTConfiguration.DEFAULT_CONTACT_PORT;
	private final static String JoinHOST = "174.129.217.111";

	private DHT<MessageObject> dht = null;
	private DHTConfiguration dhtConfig = null;
	
    private Handler mainHandler = new MainHandler(); 

    
	private EditText putKey = null;
	private EditText putValue = null;
	private EditText getKey = null;
	private EditText logView = null;
	
	private Button putButton = null;
	private Button getButton = null;
	
	private OnClickListener putListerner = new OnClickListener() {

		@Override
		public void onClick(View v) {
			String key = putKey.getText().toString();
			String value = putValue.getText().toString();
			try {
				dht.put(ID.getSHA1BasedID(key.getBytes()), new MessageObject(value));
				logView.append("PUT command : Key=" + key + "  Value=" + value + "\n");
			} catch (Exception e) {
				logView.append("PUT command : Key=" + key + "  Value=" + value + "  のPUTに失敗しました。\n");
				
			}
		}
		
	};
	private OnClickListener getListerner = new OnClickListener() {

		@Override
		public void onClick(View v) {
			String key = getKey.getText().toString();

			Set<ValueInfo<MessageObject>> values = null;
			try {
				values = dht.get(ID.getSHA1BasedID(key.getBytes()));
				for(ValueInfo<MessageObject> mo : values) {
					logView.append("GET command : Key=" + key + "  Value=" + mo.getValue().getFirst() + "\n");
				}
			} catch (RoutingException e) {
				logView.append("GET command : Key=" + key + " のgetに失敗しました。\n");
			}
			
		}
		
	};
	
	
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Window win = getWindow();
        win.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        
        
        putKey = (EditText)findViewById(R.id.put_key_edit_view);
        putValue = (EditText)findViewById(R.id.put_value_edit_view);
        getKey = (EditText)findViewById(R.id.get_key_edit_view);
        logView = (EditText)findViewById(R.id.log_view);
        
        putButton = (Button)findViewById(R.id.put_button);
        getButton = (Button)findViewById(R.id.get_button);
        
        putButton.setOnClickListener(putListerner);
        getButton.setOnClickListener(getListerner);
        
    }
    
    
	@Override
	protected void onStart() {
		super.onStart();
        if(dht != null) {
        	return;
        }
        
		try {
			if (mainHandler != null) {
				mainHandler.sendMessage
					(mainHandler.obtainMessage
					 (SHOW_LOADING));
			}
			
			// アドレスの取得
			InetAddress ipAddr = getLocalAddress();
			Log.d("DHT", ipAddr.getHostAddress());

			// コンフィグ設定。変える場合は、自分でブートストラップを用意してください。
			dhtConfig = DHTFactory.getDefaultConfiguration();
			dhtConfig.setImplementationName("ChurnTolerantDHT");
			dhtConfig.setMessagingTransport("TCP");
			dhtConfig.setContactPort(OW_PORT);
			dhtConfig.setSelfPortRange(4);
			dhtConfig.setDoUPnPNATTraversal(false);
			dhtConfig.setRoutingAlgorithm("Chord");
			dhtConfig.setRoutingStyle("Iterative");
			dhtConfig.setDirectoryType("VolatileMap");
			dhtConfig.setWorkingDirectory("./hash");
			
			MessagingUtility.HostAndPort hostAndPort =
				MessagingUtility.parseHostnameAndPort(ipAddr.getHostAddress(), OW_PORT);
			dhtConfig.setSelfAddress(hostAndPort.getHostName());
			dhtConfig.setSelfPort(hostAndPort.getPort());
			
			dht = DHTFactory.getDHT(APPLICATION_ID, APPLICATION_VERSION, dhtConfig, null);
			
			
			InetAddress bsIP = getBootstrapServer(ipAddr);
			if(bsIP == null) {
				logView.append("Only mode... \n");
			} else {
				dht.joinOverlay(bsIP.getHostAddress(), OW_PORT);
			}
			
		} catch (Exception e) {
			logView.append("Don't join DHT network... now local mode... \n");
		} finally {
			if (mainHandler != null) {
				mainHandler.sendMessage
					(mainHandler.obtainMessage
					 (HIDE_LOADING));
			}
		}
	}
	

	


	private static final int DIALOG_LOADING = 0;
	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case DIALOG_LOADING: {
			ProgressDialog dialog = new ProgressDialog(this);
			dialog.setMessage("Loading ...");
			// dialog.setIndeterminate(true);
			dialog.setCancelable(false);
			dialog.getWindow().setFlags
				(WindowManager.LayoutParams.FLAG_BLUR_BEHIND,
				 WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
			return dialog;
		}
		default:
			return super.onCreateDialog(id);
		}
	}
	
	
	public static final int SHOW_LOADING = 5;
	public static final int HIDE_LOADING = 6;
    private class MainHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
    			case SHOW_LOADING: {
    				showDialog(DIALOG_LOADING);
    				break;
    			}
    			case HIDE_LOADING: {
    				try {
    					dismissDialog(DIALOG_LOADING);
    					removeDialog(DIALOG_LOADING);
    				} catch (IllegalArgumentException e) {
    				}
    				break;
    			}
            }
        }
    }

    
    
    private InetAddress getBootstrapServer(InetAddress hostIP) {
    	
    	InetSocketAddress iSock = new InetSocketAddress(JoinHOST, OW_PORT);
		Socket socket = null;
		InputStream in = null;
		OutputStream out = null;
		try {
			socket = new Socket();
			socket.connect(iSock, 3000);
			out = socket.getOutputStream();
			ObjectOutputStream oout = new ObjectOutputStream(out);
			oout.writeObject(hostIP.getHostName());
			
			in = socket.getInputStream();
		    ObjectInputStream oin = new ObjectInputStream(in);
		    String bsIP = (String)oin.readObject();
		    if(bsIP.equals(hostIP.getHostName())) {
		    	return null;
		    }
		    InetAddress iNetAddr = InetAddress.getByName(bsIP);
		    return iNetAddr;
		    
		} catch (Exception e) {
		} finally {
			try {
				if (socket != null) {
					socket.close();
					socket = null;
				}
			} catch (IOException e) {
				/* ignore */
			}
		}
		return null;
    	
    }
    
    private InetAddress getLocalAddress() {
		Enumeration enuIfs = null;
		try {
			enuIfs = NetworkInterface.getNetworkInterfaces();
		} catch (SocketException e) {
			e.printStackTrace();
		}
		InetAddress ipAddr = null;
		if(null != enuIfs) {
		    while(enuIfs.hasMoreElements()) {
		    	Log.d("DHT", "INTERFECE FOUND");
		        NetworkInterface nic = (NetworkInterface)enuIfs.nextElement();
		        Log.d("DHT", "getDisplayName:\t" + nic.getDisplayName());
		        Log.d("DHT", "getName:\t" + nic.getName());
		        Enumeration enuAddrs = nic.getInetAddresses();
		        while (enuAddrs.hasMoreElements()) {
		            ipAddr = (InetAddress)enuAddrs.nextElement();
		            Log.d("DHT", "getHostAddress:\t" + ipAddr.getHostAddress());
		            if(!ipAddr.getHostAddress().equals("127.0.0.1")) {
		            	break;
		            }
		        }
		    }
		}
		return ipAddr;
	}
    
}