package jp.android_group.artoolkit.gae.server.server;

import jp.nyatla.utils.ByteUtil;
import jp.nyatla.utils.IntArrayValue;

public class ARToolkitParam {
	
	private int height;
	private int width;
	
	private byte[] cameraImage;
	private byte[] camePara;
	private byte[] patt;
	
	
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public byte[] getCameraImage() {
		return cameraImage;
	}
	public void setCameraImage(byte[] cameraImage) {
		this.cameraImage = convertRGBtoRBG(cameraImage);
	}
	public byte[] getCamePara() {
		return camePara;
	}
	public void setCamePara(byte[] camePara) {
		this.camePara = camePara;
	}
	public byte[] getPatt() {
		return patt;
	}
	public void setPatt(byte[] patt) {
		this.patt = patt;
	}

	private byte[] convertRGBtoRBG(byte[] cameByte) {
		IntArrayValue intArray = (IntArrayValue)ByteUtil.b2o(cameByte);
		int[] pixels = intArray.intArray;
		byte[] buf = new byte[pixels.length * 3];
		
		for (int i = 0; i < pixels.length; i++) {
			int argb = pixels[i];
			// byte a = (byte) (argb & 0xFF000000 >> 24);
			byte r = (byte) (argb & 0x00FF0000 >> 16);
			byte g = (byte) (argb & 0x0000FF00 >> 8);
			byte b = (byte) (argb & 0x000000FF);
			buf[i * 3] = r;
			buf[i * 3 + 1] = g;
			buf[i * 3 + 2] = b;
			argb = pixels[i];
		}
		return buf;
	}
	
}
