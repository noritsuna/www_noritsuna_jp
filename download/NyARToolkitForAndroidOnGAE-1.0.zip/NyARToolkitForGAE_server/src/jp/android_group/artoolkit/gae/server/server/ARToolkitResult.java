package jp.android_group.artoolkit.gae.server.server;

public class ARToolkitResult {
	
	private boolean is_marker_exist;
	
	private float[] cameraRHf = null;
	private float[] resultf = null;

	
	public boolean isIs_marker_exist() {
		return is_marker_exist;
	}
	public void setIs_marker_exist(boolean is_marker_exist) {
		this.is_marker_exist = is_marker_exist;
	}
	public float[] getCameraRHf() {
		return cameraRHf;
	}
	public void setCameraRHf(float[] cameraRHf) {
		this.cameraRHf = cameraRHf;
	}
	public float[] getResultf() {
		return resultf;
	}
	public void setResultf(float[] resultf) {
		this.resultf = resultf;
	}
	
	public String getResult() {
		if(cameraRHf == null || resultf == null) {
			return null;
		}
		
		StringBuilder sb = new StringBuilder();
		
		for(int i = 0; i < cameraRHf.length; i++) {
			sb.append(cameraRHf[i]);
			sb.append(",");
		}
		for(int i = 0; i < resultf.length; i++) {
			sb.append(resultf[i]);
			sb.append(",");
		}
		
		return sb.toString();
	}
	
}
