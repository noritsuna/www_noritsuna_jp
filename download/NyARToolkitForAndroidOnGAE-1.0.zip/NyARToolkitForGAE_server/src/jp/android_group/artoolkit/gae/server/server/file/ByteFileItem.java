package jp.android_group.artoolkit.gae.server.server.file;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Map;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemHeaders;
import org.apache.commons.fileupload.FileItemHeadersSupport;
import org.apache.commons.fileupload.ParameterParser;

public class ByteFileItem implements FileItem, FileItemHeadersSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1L;
	
	
    /**
     * Default content charset to be used when no explicit charset
     * parameter is provided by the sender. Media subtypes of the
     * "text" type are defined to have a default charset value of
     * "ISO-8859-1" when received via HTTP.
     */
    public static final String DEFAULT_CHARSET = "ISO-8859-1";

    /**
     * The name of the form field as provided by the browser.
     */
    private String fieldName;


    /**
     * The content type passed by the browser, or <code>null</code> if
     * not defined.
     */
    private String contentType;


    /**
     * Whether or not this item is a simple form field.
     */
    private boolean isFormField;


    /**
     * The original filename in the user's filesystem.
     */
    private String fileName;


    /**
     * The size of the item, in bytes. This is used to cache the size when a
     * file item is moved from its original location.
     */
    private long size = -1;


    /**
     * The threshold above which uploads will be stored on disk.
     */
    private int sizeThreshold;

    /**
     * Cached contents of the file.
     */
    private byte[] contentByte = null;
    private ByteArrayOutputStream contentByteStream = new ByteArrayOutputStream();

    /**
     * The file items headers.
     */
    private FileItemHeaders headers;

    
    
    
	
	public ByteFileItem(String fieldName, String contentType,
            boolean isFormField, String fileName, int sizeThreshold) {
        this.fieldName = fieldName;
        this.contentType = contentType;
        this.isFormField = isFormField;
        this.fileName = fileName;
        this.sizeThreshold = sizeThreshold;
	}
	

	@Override
	public void delete() {
	}

	@Override
	public byte[] get() {
		if(contentByte == null)
			contentByte = contentByteStream.toByteArray();
        return contentByte;
	}

	@Override
	public String getContentType() {
		return this.contentType;
	}

	@Override
	public String getFieldName() {
		return this.fieldName;
	}

	@Override
	public InputStream getInputStream() throws IOException {
		if(contentByte != null) {
			contentByte = null;
			contentByteStream.reset();
		}
        return new ByteArrayInputStream(contentByteStream.toByteArray());
	}

	@Override
	public String getName() {
		return this.fileName;
	}

	@Override
	public OutputStream getOutputStream() throws IOException {
		return contentByteStream;
	}

	@Override
	public long getSize() {
        if (contentByteStream != null) {
            return contentByteStream.size();
        }
        return 0;
	}

	@Override
    public String getString() {
        byte[] rawdata = get();
        String charset = getCharSet();
        if (charset == null) {
            charset = DEFAULT_CHARSET;
        }
        try {
            return new String(rawdata, charset);
        } catch (UnsupportedEncodingException e) {
            return new String(rawdata);
        }
    }

	@Override
	public String getString(final String charset) throws UnsupportedEncodingException {
        return new String(get(), charset);
	}

	@Override
	public boolean isFormField() {
		return this.isFormField ;
	}

	@Override
	public boolean isInMemory() {
		return true;
	}

	@Override
	public void setFieldName(String arg0) {
		this.fieldName = arg0;
	}

	@Override
	public void setFormField(boolean arg0) {
		this.isFormField = arg0;
	}

	@Override
	public void write(File file) throws Exception {
	}

	@Override
	public FileItemHeaders getHeaders() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setHeaders(FileItemHeaders arg0) {
		// TODO Auto-generated method stub
		
	}

	
    public String getCharSet() {
        ParameterParser parser = new ParameterParser();
        parser.setLowerCaseNames(true);
        // Parameter parser can handle null input
        Map params = parser.parse(getContentType(), ';');
        return (String) params.get("charset");
    }

}
