package jp.android_group.artoolkit.gae.server.server;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.android_group.artoolkit.gae.server.server.file.ByteFileItemFactory;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

@SuppressWarnings("serial")
public class ARToolkitDetectServlet  extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4663671193805314186L;

	public void doPost(HttpServletRequest request,
		      HttpServletResponse response) {
		String returnCode = "ARToolkitDetectServlet::";
		ARToolkitResult result = null;
		
	    try {
		    FileItemFactory factory = new ByteFileItemFactory();
		    ServletFileUpload upload = new ServletFileUpload(factory);
		    upload.setSizeMax(-1);
		    
		    ARToolkitParam param = new ARToolkitParam();
		    
	        List list = upload.parseRequest(request);
	        Iterator iterator = list.iterator();
	        while(iterator.hasNext()){
	        	FileItem fItem = (FileItem)iterator.next();
	        	if(!(fItem.isFormField())){
	        		String fileName = fItem.getName();
	        		if((fileName == null) || (fileName.equals(""))){
	        			continue;
	        		}
        			returnCode += fileName;
        			returnCode += "::";
        			returnCode += fItem.getSize();
        			returnCode += "    ";
        			
        			if(fileName.equals("camePara")) {
        				param.setCamePara(fItem.get());	        				
        			} else if(fileName.equals("patt")) {
        				param.setPatt(fItem.get());	        				
        			} else if(fileName.equals("cameImage")) {
        				param.setCameraImage(fItem.get());	        				
        			}
        			
	        	} else {
	        		String fieldName = fItem.getFieldName();
	        		if((fieldName == null) || (fieldName.equals(""))){
	        			continue;
	        		}
        			if(fieldName.equals("height")) {
            			returnCode += fieldName;
            			returnCode += "::";
            			returnCode += fItem.getString();
        	        	param.setHeight(Integer.parseInt(fItem.getString()));
        			} else if(fieldName.equals("width")) {
            			returnCode += fieldName;
            			returnCode += "::";
            			returnCode += fItem.getString();
        	        	param.setWidth(Integer.parseInt(fItem.getString()));
        			}
	        	}
	        }
	        if(param.getCamePara() != null
	         && param.getCameraImage() != null
	         && param.getPatt() != null) {
	        	
				ARToolkitProcessor proc = new ARToolkitProcessor();
				result = proc.doProcess(param);
	        }
		} catch (FileUploadException e) {
			returnCode += e.toString();
		} catch (Exception e) {
			returnCode += e.toString();
		}	    
		
		PrintWriter out = null;
		try {
			out = response.getWriter();
			if(result != null && result.getResult() != null) {
				out.write(result.getResult() + returnCode);
			} else {
				out.write(returnCode);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			out.close();
		}

	}
	
	public void doGet(HttpServletRequest request,
		      HttpServletResponse response) {

	}
	
	
	

}
