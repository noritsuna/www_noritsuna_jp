package jp.android_group.artoolkit.gae.server.server;

import jp.nyatla.nyartoolkit.NyARException;
import jp.nyatla.nyartoolkit.core.NyARCode;
import jp.nyatla.nyartoolkit.core.param.NyARParam;
import jp.nyatla.nyartoolkit.core.raster.rgb.NyARRgbRaster_RGB;
import jp.nyatla.nyartoolkit.core.transmat.NyARTransMatResult;
import jp.nyatla.nyartoolkit.detector.NyARSingleDetectMarker;
import jp.nyatla.nyartoolkit.jogl.utils.NyARGLUtil;

public class ARToolkitProcessor {
	
	private NyARSingleDetectMarker nya = null;
	private NyARRgbRaster_RGB raster = null;
	private NyARGLUtil ar_util = null;
	private NyARParam ar_param = null;
	private NyARCode ar_code = new NyARCode(16, 16);
	private NyARTransMatResult ar_transmat_result = new NyARTransMatResult();
	
	
	public ARToolkitProcessor() {
		
	}
	
	
	public ARToolkitResult doProcess(ARToolkitParam param) throws NyARException {
		
		ARToolkitResult result = new ARToolkitResult();
		
		createNyARTool(param);
		raster = NyARRgbRaster_RGB.wrap(param.getCameraImage(), param.getWidth(), param.getHeight());
		// Marker detection 
		result.setIs_marker_exist(nya.detectMarkerLite(raster, 100));
		
		// An OpenGL object will be drawn if matched.
		if (result.isIs_marker_exist()) {
			// Projection transformation.
			float[] cameraRHf = new float[16];
			float[] resultf = new float[16];
			ar_util.toCameraFrustumRHf(ar_param, cameraRHf);
			NyARTransMatResult transmat_result = ar_transmat_result;
			nya.getTransmationMatrix(transmat_result);
			ar_util.toCameraViewRHf(transmat_result, resultf);
			result.setCameraRHf(cameraRHf);
			result.setResultf(resultf);
			return result;
		}
		return null;
	}
	
	private void createNyARTool(ARToolkitParam param) throws NyARException {
		// NyARToolkit setting.
		ar_util = new NyARGLUtil();
		ar_param = new NyARParam();
		ar_param.loadARParam(param.getCamePara());
		ar_code.loadARPatt(param.getPatt());
		ar_param.changeScreenSize(param.getWidth(), param.getHeight());
		nya = new NyARSingleDetectMarker(ar_param, ar_code, 80.0);
		nya.setContinueMode(false);
	}

}
