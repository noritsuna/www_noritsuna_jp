package jp.android_group.artoolkit.hardware;

import java.text.Format;

import jp.android_group.artoolkit.NyARToolkitAndroidActivity;
import android.graphics.PixelFormat;
import android.hardware.Camera;
import android.hardware.Camera.Parameters;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.PreviewCallback;
import android.hardware.Camera.Size;
import android.os.Message;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.ViewGroup;
import android.widget.ListView.FixedViewInfo;

/**
 * It is implementing of CameraIF for Camera classe. 
 * R33.
 * 
 * @author noritsuna
 *
 */
public class AttachedCamera implements CameraIF {

	private Camera camera = null;
	private PreviewCallback cb = null;
	private CaptureThread mCaptureThread = null;
	
    private SurfaceView mSurfaceView;
    private SurfaceHolder mSurfaceHolder = null;
	private int mViewFinderWidth, mViewFinderHeight;
	private boolean mPreviewing = false;

    private JpegPictureCallback mJpegPictureCallback = new JpegPictureCallback();
    private final class JpegPictureCallback implements PreviewCallback {
		@Override
        public void onPreviewFrame(byte [] jpegData, Camera camera) {
			Log.d("mJpegPictureCallback", "data= nonCheck");
        	if(cb != null && jpegData != null) {
				Log.d("mJpegPictureCallback", "data= OK");
	    		cb.onPreviewFrame(jpegData, camera);
        	} else {
				try {
					// The measure against over load. 
					Thread.sleep(500);
				} catch (InterruptedException e) {
					;
				}
        	}
//        	// notify takePicture loop.
//        	synchronized(mCaptureThread) {
//        		mCaptureThread.notify();
//        	}
        }
    };
	
	public AttachedCamera(NyARToolkitAndroidActivity mMainActivity, SurfaceView mSurfaceView) {
		camera = Camera.open();
		
	    this.mSurfaceView = mSurfaceView;
        SurfaceHolder holder = mSurfaceView.getHolder();
        holder.addCallback(mMainActivity);
        holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);

	}

	@Override
	public Parameters getParameters() {
		return camera.getParameters();
	}

	@Override
	public void onDestroy() {
		camera.release();
	}

	@Override
	public void setParameters(Parameters params) {
		camera.setParameters(params);
	}

	@Override
	public void setPreviewCallback(PreviewCallback cb) {
		this.cb = cb;
		
	}

	@Override
	public void onStart() {
        restartPreview();

		Log.d("AttachedCamera", "call onStart");

//		if(this.mCaptureThread == null) {
//			this.mCaptureThread = new CaptureThread();
//		}
//		if(this.mCaptureThread.mDone) {
//			this.mCaptureThread.mDone = false;
//			this.mCaptureThread.start();
//		}
	}

	@Override
	public void onStop() {
		Log.d("AttachedCamera", "call onStop");
//		this.mCaptureThread.mDone = true;
//		
        stopPreview();
	}
	
	@Override
	public void onPause() {
		this.onStop();
	}
	@Override
	public void onResume() {
		this.onStart();
	}



	@Override
	public void resetPreviewSize(int width, int height) {
		// TODO Auto-generated method stub
		
	}
	

	@Override
	public void handleMessage(Message msg) {
		// TODO Auto-generated method stub
		
	}

	
	
	private class CaptureThread extends Thread {
		private boolean mDone = true;
		
		public CaptureThread() {
			super();
			Log.d("CaptureThread", "new");
		}
		@Override
		public void run() {
			Log.d("CaptureThread", "in capture thread");
			while(!mDone) {
        		camera.setPreviewCallback(mJpegPictureCallback);
	        	synchronized(mCaptureThread) {
					try {
						// Wait until processing of ARToolkit finishes. 
						mCaptureThread.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
	        	}
			}
		}
	}

	
	
	
    public void restartPreview() {
		Log.d("restartPreview", "in restartPreview.");

        SurfaceView surfaceView = mSurfaceView;
        if (surfaceView == null || 
                surfaceView.getWidth() == 0 || surfaceView.getHeight() == 0) {
    		Log.d("restartPreview", "surfaceView = null");
            return;
        }
        // make sure the surfaceview fills the whole screen when previewing
        ViewGroup.LayoutParams lp = surfaceView.getLayoutParams();
        lp.width = ViewGroup.LayoutParams.FILL_PARENT;
        lp.height = ViewGroup.LayoutParams.FILL_PARENT;
        surfaceView.requestLayout();
        setViewFinder(mViewFinderWidth, mViewFinderHeight, true);
    }
    
    private void setViewFinder(int w, int h, boolean startPreview) {
		Log.d("setViewFinder", "in setViewFinder.");
		Log.d("setViewFinder", "w=" + w + "  h=" + h);
        if (mPreviewing && 
                w == mViewFinderWidth && 
                h == mViewFinderHeight) {
    		Log.d("setViewFinder", "in no change size.");
            return;
        }
        
        if (mSurfaceHolder == null) {
    		Log.d("setViewFinder", "in mSurfaceHolder is null.");
            return;
        }
        
        // remember view finder size
        mViewFinderWidth = w;
        mViewFinderHeight = h;

        if (startPreview == false) {
    		Log.d("setViewFinder", "in startPreview = false.");
            return;
        }

        /* 
         * start the preview if we're asked to...
         */

        // we want to start the preview and we're previewing already,
        // stop the preview first (this will blank the screen).
        if (mPreviewing)
            stopPreview();
        
        // this blanks the screen if the surface changed, no-op otherwise
        camera.setPreviewDisplay(mSurfaceHolder);
		camera.setPreviewCallback(mJpegPictureCallback);
        

        // request the preview size, the hardware may not honor it,
        // if we depended on it we would have to query the size again        
        Parameters p = camera.getParameters();
        p.setPreviewSize(w, h);
        p.setPreviewFormat(PixelFormat.JPEG);
        p.setPictureFormat(PixelFormat.JPEG);
        camera.setParameters(p);
        
        

		Log.d("setViewFinder", "start mCameraDevice.startPreview().");
        camera.startPreview();
        mPreviewing = true;    	
        
    }
    
    private void stopPreview() {
    	Log.d("stopPreview", "in stopPreview.");
        if (camera != null && mPreviewing) {
        	camera.stopPreview();
        }
        mPreviewing = false;
    	Log.d("startPreview", "out stopPreview.");
    }
    public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
        // if we're creating the surface, start the preview as well.
    	Log.d("AttachedCamera", "in surfaceChanged.");
        boolean preview = holder.isCreating();
        setViewFinder(w, h, preview);
        restartPreview();
    }

    public void surfaceCreated(SurfaceHolder holder) {
    	Log.d("AttachedCamera", "in surfaceCreated.");
        mSurfaceHolder = holder;
        restartPreview();
    }

    public void surfaceDestroyed(SurfaceHolder holder) {
    	Log.d("AttachedCamera", "in surfaceDestroyed.");
        stopPreview();
        mSurfaceHolder = null;
    }

	
}
