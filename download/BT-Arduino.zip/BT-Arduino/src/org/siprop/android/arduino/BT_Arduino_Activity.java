package org.siprop.android.arduino;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

import backport.android.bluetooth.BluetoothAdapter;
import backport.android.bluetooth.BluetoothDevice;
import backport.android.bluetooth.BluetoothServerSocket;
import backport.android.bluetooth.BluetoothSocket;
import backport.android.bluetooth.protocols.BluetoothProtocols;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class BT_Arduino_Activity extends Activity {
	
	static final String ARDUINO_NAME = "ARDUINOBT";
	
    private static final String TAG = BT_Arduino_Activity.class.getSimpleName();

    private static final int REQUEST_DISCOVERY = 0x1;;

	private Handler _handler = new MainHandler();

    private static final int CONNECT = 1;
    private static final int DISCONNECT = 2;
    private static final int READ = 3;
    private static final int SEND = 4;

    private BluetoothSocket socket = null;
    
    private TextView resultText;
	
	private BluetoothAdapter _bluetooth = BluetoothAdapter.getDefaultAdapter();

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        if (!_bluetooth.isEnabled()) {
            finish();
            return;
        }
        
        setContentView(R.layout.main);

        resultText = (TextView) findViewById(R.id.TextView01);
        
        Button read = (Button) findViewById(R.id.Button01);
        read.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
	            Log.d("Bluetooth", "in read onClick.");
	        	Message msg = new Message();
	        	msg.what = READ;
	        	_handler.sendMessage(msg);
			}
		});
        Button send = (Button) findViewById(R.id.Button02);
        send.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
	            Log.d("Bluetooth", "in Send onClick.");
	        	Message msg = new Message();
	        	msg.what = SEND;
	        	byte[] sendData = {'s', 'e', 'n', 'd'};
	        	msg.obj = sendData;
	        	_handler.sendMessage(msg);
			}
		});
        
        Intent intent = new Intent(this, DiscoveryActivity.class);
        Toast.makeText(this, "select device to connect", Toast.LENGTH_SHORT)
                        .show();
        startActivityForResult(intent, REQUEST_DISCOVERY);        
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	
        if (requestCode != REQUEST_DISCOVERY) {
            return;
        }

        if (resultCode != RESULT_OK) {
            return;
        }

        final BluetoothDevice device = data
                        .getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);

        new Thread() {
            public void run() {
                    connect(device);
            };
        }.start();
    }

    @Override
	protected void onStop() {
		super.onStop();
    	Message msg = new Message();
    	msg.what = DISCONNECT;
    	_handler.sendMessage(msg);
	}

	protected void connect(BluetoothDevice device) {
    	Message msg = new Message();
    	msg.what = CONNECT;
    	msg.obj = device;
    	_handler.sendMessage(msg);
        Log.d("Bluetooth", "send CONNECT handler.");
    }
    
// ---------------------------- Handler classes ---------------------------------	
    
    /** This Handler is used to post message back onto the main thread of the application */
    private class MainHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case CONNECT: {
		            Log.d("Bluetooth", "in CONNECT handler.");
                    if (msg.obj != null && msg.obj instanceof BluetoothDevice) {
                        Log.d("Bluetooth", "createRfcommSocketToServiceRecord.");
                    	BluetoothDevice device = (BluetoothDevice)msg.obj;
                        try {
							socket = device.createRfcommSocketToServiceRecord(BluetoothProtocols.RFCOMM_PROTOCOL_UUID, 1);
	                        socket.connect();
						} catch (IOException e) {
							e.printStackTrace();
						}
                    }
                    break;
                }
                case DISCONNECT: {
		            Log.d("Bluetooth", "in DISCONNECT handler.");
                	if(socket == null) {
                		return;
                	}
                	try {
						socket.close();
					} catch (IOException e) {
						e.printStackTrace();
					} finally {
	                	socket = null;
					}
                    break;
                }
                case READ: {
		            Log.d("Bluetooth", "in READ handler.");
                	if(socket == null) {
                		return;
                	}
    	    		byte[] b = new byte[1024];
    				try {
    					InputStream in;
    					in = socket.getInputStream();
    					int readLen = in.read(b);
    		            Log.d("Bluetooth", "get input.");
    		            Log.d("Bluetooth", new String(b, 0 , readLen));
    		            resultText.append("read:" + new String(b, 0 , readLen) + "\n");
    				} catch (IOException e) {
    					e.printStackTrace();
    				}
                    break;
                }
                case SEND: {
		            Log.d("Bluetooth", "in SEND handler.");
                	if(socket == null) {
                		return;
                	}
                    if (msg.obj != null && msg.obj instanceof byte[]) {
                        Log.d("Bluetooth", "sendData OK.");
                        byte[] sendData = (byte[])msg.obj;
    		            Log.d("Bluetooth", "send:" + new String(sendData));
	    				try {
	    					OutputStream out;
	    					out = socket.getOutputStream();
	    					out.write(sendData);
	    		            Log.d("Bluetooth", "get output.");
	    		            resultText.append("send:" + new String(sendData));
	    				} catch (IOException e) {
	    					e.printStackTrace();
	    				}
                    }
                    break;
                }
            }
        }
    }
    
}