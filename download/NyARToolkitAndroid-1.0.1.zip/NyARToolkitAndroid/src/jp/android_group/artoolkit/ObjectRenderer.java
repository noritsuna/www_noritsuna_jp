/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package jp.android_group.artoolkit;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.opengles.GL10;

import jp.android_group.artoolkit.object.ARObject;
import jp.android_group.artoolkit.view.GLBg;
import android.graphics.Bitmap;

/**
 * Rendering 3DObjects.
 * 
 * @author noritsuna
 *
 */
public class ObjectRenderer implements Renderer {
	
	private GLBg bg = null;
	private ARObject arObj;

	private Bitmap bgBitmap;
	
	private int bgTextureName = -1;
	private float [] resultf = new float[16];
	private float [] cameraRHf = new float[16];

	private boolean bgChangep = false;
	private boolean drawp = false;


	public ObjectRenderer(boolean useTranslucentBackground, ARObject arObj) {
        mTranslucentBackground = useTranslucentBackground;
        this.arObj = arObj;
    }

	public void setBgBitmap(Bitmap bm) {
		bgBitmap = bm;
		bgChangep = true;
	}

    public void objectPointChanged(float[] resultf, 
								   float[] cameraRHf) {
		synchronized (this) {
			for (int i = 0; i < 16; i++) {
				this.resultf[i] = resultf[i];
				this.cameraRHf[i] = cameraRHf[i];
			}
		}
		drawp = true;
    }
	public void objectClear() {
		drawp = false;
	}

	
	private void loadBitmap(GL10 gl) {
		if (bgTextureName != -1) {
			bg.deleteTexture(gl, bgTextureName);
		}
		if (bgBitmap != null) {
			bgTextureName = bg.createTexture(gl);
			bg.loadTexture(gl, bgTextureName, bgBitmap);
			bgChangep = false;
		}
	}

	private void initBg(GL10 gl) {
		if (bg == null) {
			bg = new GLBg();
		}
		loadBitmap(gl);
	}

	private void resetProjection(GL10 gl) {
		gl.glMatrixMode(GL10.GL_PROJECTION);
		gl.glLoadMatrixf(cameraRHf, 0);
 		gl.glEnable(GL10.GL_DEPTH_TEST);
	}
	
	    
    
    public void drawFrame(GL10 gl) {
		if (bgChangep)
			loadBitmap(gl);

        /*
         * Usually, the first thing one might want to do is to clear
         * the screen. The most efficient way of doing this is to use
         * glClear().
         */
        gl.glClear(GL10.GL_COLOR_BUFFER_BIT | GL10.GL_DEPTH_BUFFER_BIT);

		// Check BG.
		if (bgBitmap != null && bgTextureName != -1) {
			bg.draw(gl, bgTextureName, bgBitmap);
			// re-setting Projection
			resetProjection(gl);
		}

        /*
         * Now we're ready to draw some 3D objects
         */
		if (drawp) {
			gl.glMatrixMode(GL10.GL_MODELVIEW);
			gl.glLoadMatrixf(resultf, 0);
		
			gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);
			gl.glEnableClientState(GL10.GL_COLOR_ARRAY);
		
			arObj.draw(gl);
		}
    }

    public int[] getConfigSpec() {
        if (mTranslucentBackground) {
                // We want a depth buffer and an alpha buffer
                int[] configSpec = {
                		EGL10.EGL_BUFFER_SIZE,   24,
                        EGL10.EGL_RED_SIZE,      8,
                        EGL10.EGL_GREEN_SIZE,    8,
                        EGL10.EGL_BLUE_SIZE,     8,
                        EGL10.EGL_ALPHA_SIZE,    8,
                        EGL10.EGL_DEPTH_SIZE,   16,
                        EGL10.EGL_NONE
                };
                return configSpec;
            } else {
                // We want a depth buffer, don't care about the
                // details of the color buffer.
                int[] configSpec = {
                		EGL10.EGL_BUFFER_SIZE,   24,
                        EGL10.EGL_RED_SIZE,      8,
                        EGL10.EGL_GREEN_SIZE,    8,
                        EGL10.EGL_BLUE_SIZE,     8,
                        EGL10.EGL_DEPTH_SIZE,   16,
                        EGL10.EGL_NONE
                };
                return configSpec;
            }
    }

    public void sizeChanged(GL10 gl, int width, int height) {
         gl.glViewport(0, 0, width, height);

         /*
          * Set our projection matrix. This doesn't have to be done
          * each time we draw, but usually a new projection needs to
          * be set when the viewport is resized.
          */

		 resetProjection(gl);
		 initBg(gl);
    }

    public void surfaceCreated(GL10 gl) {
        /*
         * By default, OpenGL enables features that improve quality
         * but reduce performance. One might want to tweak that
         * especially on software renderer.
         */
        gl.glDisable(GL10.GL_DITHER);

        /*
         * Some one-time OpenGL initialization can be made here
         * probably based on features of this particular context
         */
         gl.glHint(GL10.GL_PERSPECTIVE_CORRECTION_HINT,
				   GL10.GL_FASTEST);

         if (mTranslucentBackground) {
             gl.glClearColor(0,0,0,0);
         } else {
             gl.glClearColor(1,1,1,1);
         }
         gl.glEnable(GL10.GL_CULL_FACE);
         gl.glShadeModel(GL10.GL_SMOOTH);
         gl.glEnable(GL10.GL_DEPTH_TEST);
    }
    private boolean mTranslucentBackground;
}
