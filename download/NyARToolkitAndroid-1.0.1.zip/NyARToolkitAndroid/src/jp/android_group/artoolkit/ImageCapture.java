/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package jp.android_group.artoolkit;

import android.hardware.Camera;
import android.hardware.Camera.Size;
import android.location.Location;
import android.os.Handler;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.Toast;

public class ImageCapture {
	
	private NyARToolkitAndroidActivity arActivity;	
	private Camera mCameraDevice;
	private Handler mHandler;
	
	
    public ImageCapture(NyARToolkitAndroidActivity arActivity, Handler mHandler, Camera mCameraDevice) {
    	this.arActivity = arActivity;
    	this.mHandler = mHandler;
    	this.mCameraDevice = mCameraDevice;
    }
    
    private boolean mCapturing = false;
    public boolean getCapturing() {
    	return mCapturing;
    }

    /** 
     * This method sets whether or not we are capturing a picture. This method must be called
     * with the ImageCapture.this lock held.
     */
    public void setCapturingLocked(boolean capturing) {
        mCapturing = capturing;
    }
    
    public void dismissFreezeFrame(boolean keep) {
        if (!keep) {
            Toast.makeText(arActivity, R.string.camera_tossing, Toast.LENGTH_SHORT).show();
        }
        
        if (arActivity.getStatus() == NyARToolkitAndroidActivity.SNAPSHOT_IN_PROGRESS) {
            // If we are still in the process of taking a picture, then just post a message.
            mHandler.sendEmptyMessage(NyARToolkitAndroidActivity.RESTART_PREVIEW);
        } else {
        	arActivity.restartPreview();
        }
    }

    /*
     * Initiate the capture of an image.
     */
    public boolean initiate() {
		Log.d("ImageCap", "in initiate.");
		Log.d("ImageCap", "mCameraDevice ID:" + mCameraDevice);
        if (mCameraDevice == null) {
            return false;
        }
        
        mCapturing = true;

        return capture();
    }
  
    private boolean capture() {
		Log.d("ImageCap", "in capture.");
    	arActivity.setPreviewing(false);
        
        final int latchedOrientation = NyARToolkitAndroidActivity.roundOrientation(arActivity.getLastOrientation() + 90 );

        Boolean recordLocation = arActivity.getSharedPreferences().getBoolean("pref_camera_recordlocation_key", false);
        Location loc = recordLocation ? arActivity.getCurrentLocation() : null;
        Camera.Parameters parameters = mCameraDevice.getParameters();
        // Quality 75 has visible artifacts, and quality 90 looks great but the files begin to
        // get large. 85 is a good compromise between the two.
        parameters.set("jpeg-quality", 85);
        parameters.set("rotation", latchedOrientation);
        if (loc != null) {
            parameters.set("gps-latitude",  String.valueOf(loc.getLatitude()));
            parameters.set("gps-longitude", String.valueOf(loc.getLongitude()));
            parameters.set("gps-altitude",  String.valueOf(loc.getAltitude()));
            parameters.set("gps-timestamp", String.valueOf(loc.getTime()));
        } else {
            parameters.remove("gps-latitude");
            parameters.remove("gps-longitude");
            parameters.remove("gps-altitude");
            parameters.remove("gps-timestamp");
        }

        Size pictureSize = parameters.getPictureSize();
        Size previewSize = parameters.getPreviewSize();

        // resize the SurfaceView to the aspect-ratio of the still image
        // and so that we can see the full image that was taken
        ViewGroup.LayoutParams lp = arActivity.getCameraSurfaceView().getLayoutParams();
        if (pictureSize.width*previewSize.height < previewSize.width*pictureSize.height) {
            lp.width = (pictureSize.width * previewSize.height) / pictureSize.height; 
        } else {
            lp.height = (pictureSize.height * previewSize.width) / pictureSize.width; 
        }
        arActivity.getCameraSurfaceView().requestLayout();

        mCameraDevice.setParameters(parameters);
   
		Log.d("ImageCap", "exec takePicture.");
        mCameraDevice.takePicture(null, null, arActivity.getJpegPictureCallback());
        return true;
    }

    public boolean snap(ImageCapture realCapure) {
		Log.d("ImageCap", "in onSnap");
        // If we are already in the middle of taking a snapshot then we should just save
        // the image after we have returned from the camera service.
        if (arActivity.getStatus() == NyARToolkitAndroidActivity.SNAPSHOT_IN_PROGRESS 
        		|| arActivity.getStatus() == NyARToolkitAndroidActivity.SNAPSHOT_COMPLETED) {
    		Log.d("ImageCap", "in SNAPSHOT_IN_PROGRESS.");
            arActivity.setKeepAndRestartPreview(true);
            mHandler.sendEmptyMessage(NyARToolkitAndroidActivity.RESTART_PREVIEW);
            return false;
        }

        arActivity.setStatus(NyARToolkitAndroidActivity.SNAPSHOT_IN_PROGRESS);

        arActivity.setKeepAndRestartPreview(!arActivity.getSharedPreferences().getBoolean("pref_camera_postpicturemenu_key", true));

        return realCapure.initiate();
    }
}
