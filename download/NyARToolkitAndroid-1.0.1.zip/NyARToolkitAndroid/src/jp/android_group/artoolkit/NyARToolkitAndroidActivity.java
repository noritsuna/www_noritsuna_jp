/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package jp.android_group.artoolkit;

import java.io.InputStream;

import jp.android_group.artoolkit.object.Cube;
import jp.android_group.artoolkit.object.VoicePlayer;
import jp.android_group.artoolkit.view.GLSurfaceView;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.hardware.Camera;
import android.hardware.Camera.PictureCallback;
import android.location.Location;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.preference.PreferenceManager;
import android.util.Config;
import android.util.Log;
import android.view.OrientationListener;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;

public class NyARToolkitAndroidActivity extends Activity implements View.OnClickListener, SurfaceHolder.Callback {
    
	public static final String TAG = "camera";
    
    public static final int CROP_MSG = 1;
    public static final int KEEP = 2;
    public static final int RESTART_PREVIEW = 3;
    public static final int CLEAR_SCREEN_DELAY = 4;
    
    public static final int SCREEN_DELAY = 2 * 60 * 1000;
    
    public static final String ACTION_IMAGE_CAPTURE = "ACTION_IMAGE_CAPTURE";
    


    private OrientationListener mOrientationListener;
    private int mLastOrientation = OrientationListener.ORIENTATION_UNKNOWN;
    private SharedPreferences mPreferences;
    
    public static final int IDLE = 1;
    public static final int SNAPSHOT_IN_PROGRESS = 2;
    public static final int SNAPSHOT_COMPLETED = 3;
    
    private int mStatus = IDLE;

    private Camera mCameraDevice;
    private SurfaceView mSurfaceView;
    private SurfaceHolder mSurfaceHolder = null;
    private GLSurfaceView mGLSurfaceView;
    private ObjectRenderer mRenderer;

	private int mViewFinderWidth, mViewFinderHeight;
	private boolean mPreviewing = false;

	private ImageCapture mCaptureObject;
	private ImageCapture mImageCapture = null;

	
	private boolean mPausing = false;

	private boolean mIsFocusing = false;
	private boolean mIsFocused = false;
	private boolean mCaptureOnFocus = false;

	private LocationManager mLocationManager = null;

    private JpegPictureCallback mJpegPictureCallback = new JpegPictureCallback();
    private AutoFocusCallback mAutoFocusCallback = new AutoFocusCallback();

    private boolean mKeepAndRestartPreview;

    private Handler mHandler = new MainHandler(); 
    
    public enum DataLocation { NONE, INTERNAL, EXTERNAL, ALL }

    
    private ARToolkitDrawer arToolkit = null;
    
	private CaptureThread mCaptureThread = null;
	final private Object captureThreadLockObj = new Object();
    
    private long mRawPictureCallbackTime;
    
    private LocationListener [] mLocationListeners = new LocationListener[] {
            new LocationListener(LocationManager.GPS_PROVIDER),
            new LocationListener(LocationManager.NETWORK_PROVIDER)
    };


//----------------------- Override Methods ------------------------
    
    /** Called with the activity is first created. */
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);

		mRenderer = new ObjectRenderer(false, new Cube());
				
        mLocationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        mPreferences = PreferenceManager.getDefaultSharedPreferences(this);

        requestWindowFeature(Window.FEATURE_PROGRESS);
        
        Window win = getWindow();
        win.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.camera);

        mSurfaceView = (SurfaceView) findViewById(R.id.camera_preview);
        
        // don't set mSurfaceHolder here. We have it set ONLY within
        // surfaceCreated / surfaceDestroyed, other parts of the code
        // assume that when it is set, the surface is also set.
        SurfaceHolder holder = mSurfaceView.getHolder();
        holder.addCallback(this);
        holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);

        
        mGLSurfaceView = (GLSurfaceView) findViewById(R.id.GL_view);
		mGLSurfaceView.setRenderer(mRenderer);
        
        
        mOrientationListener = new OrientationListener(this) {
            public void onOrientationChanged(int orientation) {
                mLastOrientation = orientation;
            }
        };
        
        // init VoicePlayer for ARToolkit.
        //  VoicePlayer mVoiceSound = new VoicePlayer();
        //  mVoiceSound.initVoice(getResources().openRawResourceFd(R.raw.miku_voice));
        
        
        // init ARToolkit.
		InputStream camePara = getResources().openRawResource(
				R.raw.camera_para);
		InputStream patt = getResources().openRawResource(
				R.raw.patt);
		arToolkit = new ARToolkitDrawer(camePara, patt, mRenderer);
        //arToolkit.setVoicePlayer(mVoiceSound);
        
    }
    
    @Override
    public void onStart() {
        super.onStart();
    }
    
    @Override
    public void onResume() {
        super.onResume();
        
        mHandler.sendEmptyMessageDelayed(CLEAR_SCREEN_DELAY, SCREEN_DELAY);
        
        mPausing = false;
        mOrientationListener.enable();

        ensureCameraDevice();
        mImageCapture = new ImageCapture(this, mHandler, mCameraDevice);

        restartPreview();
        
        if (mPreferences.getBoolean("pref_camera_recordlocation_key", false))
            startReceivingLocationUpdates();
    }

    @Override
    public void onStop() {
        keep();
        stopPreview();
        closeCamera();
        mHandler.removeMessages(CLEAR_SCREEN_DELAY);
        super.onStop();
    }

    @Override
    protected void onPause() {
        keep();

        mPausing = true;
        mOrientationListener.disable();
        
        stopPreview();

        if (!mImageCapture.getCapturing()) {
            closeCamera();
        }
        stopReceivingLocationUpdates();

        super.onPause();
    }
    
	@Override
	public void onClick(View v) {
		;;
	}

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case CROP_MSG: {
                Intent intent = new Intent();
                if (data != null) {
                    Bundle extras = data.getExtras();
                    if (extras != null) {
                        intent.putExtras(extras);
                    }
                }
                setResult(resultCode, intent);
                finish();
                break;
            }
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
        // if we're creating the surface, start the preview as well.
        boolean preview = holder.isCreating();
        setViewFinder(w, h, preview);
        mCaptureObject = mImageCapture;
    	startPreview();

    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        mSurfaceHolder = holder;
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        stopPreview();
        mSurfaceHolder = null;
    }
    
    
    
    
    
    
//----------------------- Camera's method ------------------------
    
    private boolean autoFocus() {
        if (!mIsFocusing) {
            if (mCameraDevice != null) {
                mIsFocusing = true;
                mIsFocused = false;
                mCameraDevice.autoFocus(mAutoFocusCallback);
                return true;
            }
        }
        return false;
    }
    
    private void clearFocus() {
        mIsFocusing = false;
        mIsFocused = false;
    }

    
    private void closeCamera() {
        if (mCameraDevice != null) {
            mCameraDevice.release();
            mCameraDevice = null;
            mPreviewing = false;
        }
    }
    
    private boolean ensureCameraDevice() {
        if (mCameraDevice == null) {
            mCameraDevice = Camera.open();
        }
        return mCameraDevice != null;
    }
    
    public void restartPreview() {
        SurfaceView surfaceView = mSurfaceView;
        if (surfaceView == null || 
                surfaceView.getWidth() == 0 || surfaceView.getHeight() == 0) {
    		Log.d("restartPreview", "surfaceView = null");
            return;
        }
        // make sure the surfaceview fills the whole screen when previewing
        ViewGroup.LayoutParams lp = surfaceView.getLayoutParams();
        lp.width = ViewGroup.LayoutParams.FILL_PARENT;
        lp.height = ViewGroup.LayoutParams.FILL_PARENT;
        surfaceView.requestLayout();
        setViewFinder(mViewFinderWidth, mViewFinderHeight, true);
        mStatus = IDLE;
    }
    
    private void setViewFinder(int w, int h, boolean startPreview) {
		Log.d("setViewFinder", "in setViewFinder.");
        if (mPausing) {
    		Log.d("setViewFinder", "in mPausing.");
            return;
        }
        
        if (mPreviewing && 
                w == mViewFinderWidth && 
                h == mViewFinderHeight) {
    		Log.d("setViewFinder", "in no change size.");
            return;
        }
        
        if (!ensureCameraDevice()) {
    		Log.d("setViewFinder", "in ensureCameraDevice.");
            return;
        }
        
        if (mSurfaceHolder == null) {
    		Log.d("setViewFinder", "in mSurfaceHolder is null.");
            return;
        }
        
        if (isFinishing()) {
    		Log.d("setViewFinder", "in fihishing.");
            return;
        }
        
        if (mPausing) {
    		Log.d("setViewFinder", "in mPausing.");
            return;
        }
        
        // remember view finder size
        mViewFinderWidth = w;
        mViewFinderHeight = h;

        if (startPreview == false) {
    		Log.d("setViewFinder", "in startPreview = false.");
            return;
        }

        /* 
         * start the preview if we're asked to...
         */

        // we want to start the preview and we're previewing already,
        // stop the preview first (this will blank the screen).
        if (mPreviewing)
            stopPreview();
        
        // this blanks the screen if the surface changed, no-op otherwise
        mCameraDevice.setPreviewDisplay(mSurfaceHolder);
        

        // request the preview size, the hardware may not honor it,
        // if we depended on it we would have to query the size again
        android.hardware.Camera.Parameters p = mCameraDevice.getParameters();
        p.setPreviewSize(w, h);
        mCameraDevice.setParameters(p);
        
        
        final long wallTimeStart = SystemClock.elapsedRealtime();
        final Object watchDogSync = new Object();
        Thread watchDog = new WatchDogThread(watchDogSync, wallTimeStart);
        watchDog.start();

		Log.d("setViewFinder", "start mCameraDevice.startPreview().");
        mCameraDevice.startPreview();
        mPreviewing = true;    	
        this.startPreview();
        
        synchronized (watchDogSync) {
            watchDogSync.notify();
        }
    }

    private void startPreview() {
    	Log.d("startPreview", "in startPreview.");
		if(this.mCaptureThread == null) {
			this.mCaptureThread = new CaptureThread();
		}
		if(this.mCaptureThread.mDone) {
	    	Log.d("startPreview", "in mDone.");
			synchronized(captureThreadLockObj) {
				this.mCaptureThread.mDone = false;
			}
			if(this.mCaptureThread.isAlive()) {
				try {
					this.mCaptureThread.join();
				} catch (InterruptedException e) {
					;;
				}
			}
			this.mCaptureThread.start();
	    	Log.d("startPreview", "out mDone.");
		}
    	Log.d("startPreview", "out startPreview.");
    }
    private void stopPreview() {
    	Log.d("stopPreview", "in stopPreview.");
        if (mCameraDevice != null && mPreviewing) {
            mCameraDevice.stopPreview();
        }
        mPreviewing = false;
        if(this.mCaptureThread != null) {
			synchronized(captureThreadLockObj) {
				this.mCaptureThread.mDone = true;
			}
        }
    	Log.d("startPreview", "out stopPreview.");
    }

    void keep() {
        if (mCaptureObject != null) {
            mCaptureObject.dismissFreezeFrame(true);
        }
    };

    
    
    private void startReceivingLocationUpdates() {
        if (mLocationManager != null) {
            try {
                mLocationManager.requestLocationUpdates(
                        LocationManager.NETWORK_PROVIDER, 
                        1000, 
                        0F, 
                        mLocationListeners[1]);
            } catch (java.lang.SecurityException ex) {
                // ok
            } catch (IllegalArgumentException ex) {
                if (Config.LOGD) {
                    Log.d(TAG, "provider does not exist " + ex.getMessage());
                }
            }
            try {
                mLocationManager.requestLocationUpdates(
                        LocationManager.GPS_PROVIDER, 
                        1000, 
                        0F, 
                        mLocationListeners[0]);
            } catch (java.lang.SecurityException ex) {
                // ok
            } catch (IllegalArgumentException ex) {
                if (Config.LOGD) {
                    Log.d(TAG, "provider does not exist " + ex.getMessage());
                }
            }
        }
    }
    
    private void stopReceivingLocationUpdates() {
        if (mLocationManager != null) {
            for (int i = 0; i < mLocationListeners.length; i++) {
                try {
                    mLocationManager.removeUpdates(mLocationListeners[i]);
                } catch (Exception ex) {
                    // ok
                }
            }
        }
    }
    
	
	
	
	
	
// ---------------------- getter & setter ---------------------------	

	public void setPreviewing(boolean b) {
		this.mPreviewing = b;
		
	}
	
	public SharedPreferences getSharedPreferences() {
		return mPreferences;
	}
   	
	public void setStatus(int state) {
		this.mStatus = state;
	}
	
	public int getStatus() {
		return this.mStatus;
	}

	public SurfaceView getCameraSurfaceView() {
		return this.mSurfaceView;
	}
	
	public void setKeepAndRestartPreview(boolean b) {
		this.mKeepAndRestartPreview = b;
	}

	public PictureCallback getJpegPictureCallback() {
		return this.mJpegPictureCallback;
	}
	
    public int getLastOrientation() {
    	return mLastOrientation;
    }
    
	
	
	
	
// ---------------------------- Utils ---------------------------------	

    
    public static int roundOrientation(int orientationInput) {
    	Log.d("roundOrientation", "orientationInput:" + orientationInput);
        int orientation = orientationInput;
        if (orientation == -1)
            orientation = 0;
        
        //orientation = orientation % 360;
        int retVal;
        if (orientation < (0*90) + 45) {
            retVal = 0;
        } else if (orientation < (1*90) + 45) {
            retVal = 90;
        } else if (orientation < (2*90) + 45) {
            retVal = 180;
        } else if (orientation < (3*90) + 45) {
            retVal = 270;
        } else {
            retVal = 0;
        }

        return retVal;
    }	
    public static Matrix GetDisplayMatrix(Bitmap b, ImageView v) {
        Matrix m = new Matrix();
        float bw = (float)b.getWidth();
        float bh = (float)b.getHeight();
        float vw = (float)v.getWidth();
        float vh = (float)v.getHeight();
        float scale, x, y;
        if (bw*vh > vw*bh) {
            scale = vh / bh;
            x = (vw - scale*bw)*0.5F;
            y = 0;
        } else {
            scale = vw / bw;
            x = 0;
            y = (vh - scale*bh)*0.5F;
        }
        m.setScale(scale, scale, 0.5F, 0.5F);
        m.postTranslate(x, y);
        return m;
    }
    
    public Location getCurrentLocation() {
        Location l = null;
        
        // go in worst to best order
        for (int i = 0; i < mLocationListeners.length && l == null; i++) {
            l = mLocationListeners[i].current();
        }        
        return l;
    }
    private class LocationListener implements android.location.LocationListener {
    	private Location mLastLocation;
    	private boolean mValid = false;
    	private String mProvider;
        
        public LocationListener(String provider) {
            mProvider = provider;
            mLastLocation = new Location(mProvider);
        }
        
        public void onLocationChanged(Location newLocation) {
            if (newLocation.getLatitude() == 0.0 && newLocation.getLongitude() == 0.0) {
                // Hack to filter out 0.0,0.0 locations
                return;
            }
            mLastLocation.set(newLocation);
            mValid = true;
        }
        
        public void onProviderEnabled(String provider) {
        }

        public void onProviderDisabled(String provider) {
            mValid = false;
        }

        public void onStatusChanged(String provider, int status, Bundle extras) {
            if (status == LocationProvider.OUT_OF_SERVICE) {
                mValid = false;
            }
        }
        
        public Location current() {
            return mValid ? mLastLocation : null;
        }
    };
	
	
// ---------------------------- Callback classes ---------------------------------	
	
    private final class JpegPictureCallback implements PictureCallback {
        public void onPictureTaken(byte [] jpegData, Camera camera) {
            Log.d("JpegPictureCallback", "in JpegPictureCallback...");
            
            mStatus = SNAPSHOT_COMPLETED;

            if (!mPreferences.getBoolean("pref_camera_postpicturemenu_key", true)) {
                if (mKeepAndRestartPreview) {
                    long delay = 1500 - (System.currentTimeMillis() - mRawPictureCallbackTime);
                    mHandler.sendEmptyMessageDelayed(RESTART_PREVIEW, Math.max(delay, 0));
                }
                Log.d("JpegPictureCallback", "end...pref_camera_postpicturemenu_key:");
                return;
            }

            if (mKeepAndRestartPreview) {
                mKeepAndRestartPreview = false;
                
                // Post this message so that we can finish processing the request. This also
                // prevents the preview from showing up before mPostPictureAlert is dismissed.
                mHandler.sendEmptyMessage(RESTART_PREVIEW);
            }
            
            
        	if(jpegData != null) {
				Log.d("JpegPictureCallback", "data= OK");
				arToolkit.draw(jpegData);
        	} else {
				try {
					// The measure against over load. 
					Thread.sleep(500);
				} catch (InterruptedException e) {
					;
				}
        	}
        	
        	// notify takePicture loop.
			Log.d("JpegPictureCallback", "check captureThreadLockObj");
        	synchronized(captureThreadLockObj) {
    			Log.d("JpegPictureCallback", "notify captureThreadLockObj");
    			captureThreadLockObj.notify();
        	}
			Log.d("JpegPictureCallback", "end....");
        }
    };
    
    private final class AutoFocusCallback implements android.hardware.Camera.AutoFocusCallback {
        public void onAutoFocus(boolean focused, android.hardware.Camera camera) {
            mIsFocusing = false;
            mIsFocused = focused;
            Log.d("AutoFocusCallback", "focused:" + mIsFocused);
            Log.d("AutoFocusCallback", "mCaptureOnFocus:" + mCaptureOnFocus);
            if (focused) {
                if (mCaptureOnFocus && mCaptureObject != null) {
                    // No need to play the AF sound if we're about to play the shutter sound
                    if(mCaptureObject.snap(mImageCapture)) {
                        clearFocus();
                        mCaptureOnFocus = false;
                        return;
                    }
                    clearFocus();
                }
                mCaptureOnFocus = false;
            }
        	// notify takePicture loop.
			Log.d("AutoFocusCallback", "check captureThreadLockObj");
        	synchronized(captureThreadLockObj) {
    			Log.d("AutoFocusCallback", "notify captureThreadLockObj");
    			captureThreadLockObj.notify();
        	}
        }
    };

    
    
    
// ---------------------------- Thread ---------------------------------	
    
	private class CaptureThread extends Thread {
		private boolean mDone = true;
		
		public CaptureThread() {
			super();
			Log.d("CaptureThread", "new");
		}
		@Override
		public void run() {
			Log.d("CaptureThread", "in capture thread");
			while(!mDone) {
				// Take picture.
				boolean isWait = false;
				if (mIsFocused || !mPreviewing) {
					Log.d("CaptureThread", "in onSnap");
					isWait = mCaptureObject.snap(mImageCapture);
				    clearFocus();
				} else {
					Log.d("CaptureThread", "in autoFocus");
				    mCaptureOnFocus = true;
				    isWait = autoFocus();
				    clearFocus();
				}
			    if(isWait) {
		        	synchronized(captureThreadLockObj) {
						try {
							// Wait until processing of ARToolkit finishes. 
							Log.d("CaptureThread", "!!!!!!!!!!!start mCaptureThread.wait()!!!!!!!!!!!!!!!");
							captureThreadLockObj.wait();
							Log.d("CaptureThread", "!!!!!!!!!!!stop mCaptureThread.wait()!!!!!!!!!!!!!!!");
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
		        	}
			    } else {
				    try {
						Thread.sleep(300);
					} catch (InterruptedException e) {
						;
					}
			    }
				
			}
			Log.d("CaptureThread", "!!!!!!!!!!!end!!!!!!!!!!!!!!!");
		}
	}
    
    private class WatchDogThread extends Thread {
        final Object watchDogSync;
        final long wallTimeStart;

    	
    	public WatchDogThread(Object locObj, long wallTimeStart) {
    		this.watchDogSync = locObj;
    		this.wallTimeStart = wallTimeStart;
    	}
    	
        public void run() {
            int next_warning = 1;
            while (true) {
                try {
                    synchronized (watchDogSync) {
                        watchDogSync.wait(1000);
                    }
                } catch (InterruptedException ex) {
                    //
                }
                if (mPreviewing)
                    break;
                
                int delay = (int) (SystemClock.elapsedRealtime() - wallTimeStart) / 1000;
                if (delay >= next_warning) {
                    if (delay < 120) {
                        Log.e(TAG, "preview hasn't started yet in " + delay + " seconds");
                    } else {
                        Log.e(TAG, "preview hasn't started yet in " + (delay / 60) + " minutes");
                    }
                    if (next_warning < 60) {
                        next_warning <<= 1;
                        if (next_warning == 16) {
                            next_warning = 15;
                        }
                    } else {
                        next_warning += 60;
                    }
                }
            }
        }
    }

    

 
    
// ---------------------------- Handler classes ---------------------------------	
    
    /** This Handler is used to post message back onto the main thread of the application */
    private class MainHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case KEEP: {
                    keep();
                    
                    mKeepAndRestartPreview = true;
                    
                    if (msg.obj != null) {
                        mHandler.post((Runnable)msg.obj);
                    }
                    break;
                }
            
                case RESTART_PREVIEW: {
                    if (mStatus == SNAPSHOT_IN_PROGRESS) {
                        // We are still in the processing of taking the picture, wait.
                        // This is is strange.  Why are we polling?
                        // TODO remove polling
                        mHandler.sendEmptyMessageDelayed(RESTART_PREVIEW, 100);
                    } else if (mStatus == SNAPSHOT_COMPLETED){
                        mCaptureObject.dismissFreezeFrame(true);
                    }
                    break;
                }
                
                case CLEAR_SCREEN_DELAY: {
                    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    break;
                }
            }
        }
    }






}

