/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package jp.android_group.artoolkit;

import javax.microedition.khronos.opengles.GL10;


/**
 * A generic renderer interface.
 */
public interface Renderer {
    /**
     * @return the EGL configuration specification desired by the renderer.
     */
    int[] getConfigSpec();

    /**
     * Surface created.
     * Called when the surface is created. Called when the application
     * starts, and whenever the GPU is reinitialized. This will
     * typically happen when the device awakes after going to sleep.
     * Set your textures here.
     */
    void surfaceCreated(GL10 gl);
    /**
     * Surface changed size.
     * Called after the surface is created and whenever
     * the OpenGL ES surface size changes. Set your viewport here.
     * @param gl
     * @param width
     * @param height
     */
    void sizeChanged(GL10 gl, int width, int height);
    /**
     * Draw the current frame.
     * @param gl
     */
    void drawFrame(GL10 gl);

}
