/* 
 * PROJECT: NyARToolkit on Android
 * --------------------------------------------------------------------------------
 * This work is based on the NyARToolKit developed by
 *   R.Iizuka
 * http://www.hitl.washington.edu/artoolkit/
 *
 * The NyARToolkit on Android is an Application of NyARToolkit 
 * to Google Android Emulator Environment.
 * Copyright (C)2008 Shinobu Izumi
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this framework; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * For further information please contact.
 *	<stagesp1(at)gmail.com>
 * 
 */
package jp.android_group.artoolkit;

import java.io.InputStream;

import jp.android_group.artoolkit.object.VoicePlayer;
import jp.nyatla.nyartoolkit.NyARException;
import jp.nyatla.nyartoolkit.core.NyARCode;
import jp.nyatla.nyartoolkit.core.raster.NyARRaster_RGB;
import jp.nyatla.nyartoolkit.jogl.utils.GLNyARParam;
import jp.nyatla.nyartoolkit.jogl.utils.GLNyARSingleDetectMarker;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

public class ARToolkitDrawer {
	
	private GLNyARSingleDetectMarker nya = null;
	private NyARRaster_RGB raster = new NyARRaster_RGB();
	private GLNyARParam ar_param = new GLNyARParam();
	private NyARCode ar_code = new NyARCode(16, 16);
	
	private ObjectRenderer mRenderer = null;
	private InputStream camePara = null;
	private InputStream patt = null;
	
	private VoicePlayer mVoiceSound = null;
	
	public ARToolkitDrawer(InputStream camePara, InputStream patt, ObjectRenderer mRenderer) {
		this.camePara = camePara;
		this.patt = patt;
		this.mRenderer = mRenderer;
	}
	
	public void setVoicePlayer(VoicePlayer mVoiceSound) {
		this.mVoiceSound = mVoiceSound;
	}

	private void createNyARTool(int w, int h) {
		// NyARToolkit setting.
		try {
			ar_param.loadFromARFile(camePara);
			ar_param.changeSize(w, h);
			ar_code.loadFromARFile(patt);
			nya = new GLNyARSingleDetectMarker(ar_param, ar_code, 80.0);
			nya.setContinueMode(true);
			Log.d("nyar", "resources have been loaded");
		} catch (Exception e) {
			Log.e("nyar", "resource loading failed", e);
		}

	}
	
	
	public void draw(byte[] data) {
		
		if(data == null) {
			Log.d("AR draw", "data= null");
			return;
		}
		
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = 4;
		Log.d("AR draw", "data.length= " + data.length);
		Bitmap bitmap = null;
		bitmap = BitmapFactory.decodeByteArray(data, 0, data.length, options);
		if (bitmap == null) {
			return;
		}
					
		Log.d("AR draw", "bitmap.getHeight()= " + bitmap.getHeight());
		Log.d("AR draw", "bitmap.getWidth()= " + bitmap.getWidth());
		if(nya == null) {
			Log.d("AR draw", "createNyARTool");
			createNyARTool(bitmap.getWidth(), bitmap.getHeight());
		}
		
		mRenderer.setBgBitmap(bitmap);
		// start coordinates calculation.
		int w = bitmap.getWidth();
		int h = bitmap.getHeight();
		int[] pixels = new int[w * h];
		byte[] buf = new byte[pixels.length * 3];
		float[] resultf = new float[16];
		
		boolean is_marker_exist = false;
		bitmap.getPixels(pixels, 0, w, 0, 0, w, h);
		Log.d("AR draw", "pixels:" + pixels.length);

		for (int i = 0; i < pixels.length; i++) {
			int argb = pixels[i];
			// byte a = (byte) (argb & 0xFF000000 >> 24);
			byte r = (byte) (argb & 0x00FF0000 >> 16);
			byte g = (byte) (argb & 0x0000FF00 >> 8);
			byte b = (byte) (argb & 0x000000FF);
			buf[i * 3] = r;
			buf[i * 3 + 1] = g;
			buf[i * 3 + 2] = b;
		}

		NyARRaster_RGB.wrap(raster, buf, w, h);
		// Marker detection 
		try {
			Log.d("AR draw", "Marker detection.");
			is_marker_exist = nya.detectMarkerLite(raster, 100);
		} catch (NyARException e) {
			Log.e("AR draw", "marker detection failed", e);
			return;
		}
		
		// An OpenGL object will be drawn if matched.
		if (is_marker_exist) {
			Log.d("AR draw", "!!!!!!!!!!!exist marker.!!!!!!!!!!!");
			// Projection transformation.
			float[] cameraRHf = ar_param.getCameraFrustumRHf();
			try {
				nya.getCameraViewRH(resultf);
			} catch (NyARException e) {
				Log.e("AR draw", "getCameraViewRH failed", e);
				return;
			}
			mRenderer.objectPointChanged(resultf, cameraRHf);
			if(mVoiceSound != null)
				mVoiceSound.startVoice();
		} else {
			Log.d("AR draw", "not exist marker.");
			if(mVoiceSound != null)
				mVoiceSound.stopVoice();
			mRenderer.objectClear();
		}

	}
	
}
