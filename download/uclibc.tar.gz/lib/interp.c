/* Force shared libraries to know about the correct library loader */
#include <features.h>
const char __dl_ldso__[] __attribute__ ((section  (".interp"))) ="/usr/arm-linux-uclibc/lib/ld-uClibc.so.0";
