LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE:= opencv_libv4l
LOCAL_C_INCLUDES += $(LOCAL_PATH)/include
LOCAL_SRC_FILES := \
logv4l1.c \
logv4l2.c \
autogain.c \
bayer.c \
cpia1.c \
crop.c \
flip.c \
gamma.c \
helper.c \
hm12.c \
jidctflt.c \
mr97310a.c \
pac207.c \
rgbyuv.c \
se401.c \
sn9c10x.c \
sn9c2028-decomp.c \
sn9c20x.c \
spca501.c \
spca561-decompress.c \
sq905c.c \
stv0680.c \
tinyjpeg.c \
whitebalance.c \
libv4l1.c \
libv4l2.c \
libv4lcontrol.c \
libv4lconvert.c \
libv4lprocessing.c



include $(BUILD_STATIC_LIBRARY)
