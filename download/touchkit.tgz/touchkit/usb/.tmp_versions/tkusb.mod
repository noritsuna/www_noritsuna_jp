/root/eg1/eGalax_Touch/touchkit/usb/tkusb.ko
/root/eg1/eGalax_Touch/touchkit/usb/tkusb.o
